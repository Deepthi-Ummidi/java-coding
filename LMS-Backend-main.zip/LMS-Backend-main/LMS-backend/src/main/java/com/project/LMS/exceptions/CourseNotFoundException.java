
package com.project.LMS.exceptions;

public class CourseNotFoundException extends RuntimeException {
	public CourseNotFoundException(String message) {
		super(message);
		}
}
