
package com.project.LMS.exceptions;

public class QuizNotFoundException extends RuntimeException {
	public QuizNotFoundException(String message) {
		super(message);
		}
}
